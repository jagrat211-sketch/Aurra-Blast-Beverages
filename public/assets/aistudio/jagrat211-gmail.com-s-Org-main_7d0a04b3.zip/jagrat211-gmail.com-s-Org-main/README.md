# Aura Artisan Beverages — Full-Stack E-Commerce Platform

A production-quality, responsive 2-page e-commerce website for an artisanal Beverage brand featuring handcrafted sparkling flavors: **Cranberry Sparkle, Mint Mojito, Zesty Lime, Mango Rush, Berry Blast, Orange Fizz, and Peach Iced Tea**.

---

## 🏗️ Architecture & Free Hosting Plan (Vercel & Free Databases)

### 1. Where the Data is Kept
- **Client Cart (Zustand + `localStorage`)**: Persists per user (`cart-<userId>`) so one user's cart is never shown to another. Survives browser restarts and page refreshes.
- **Backend Data Layer (SQLite via `better-sqlite3`)**: Keeps users, products, orders, order items, and every cart add/remove/set_qty event with server timestamps.
- **Server-Side Price Integrity**: The server resolves all prices from the products table and calculates the order total inside a single database transaction.

### 2. Image Uploads & Free Storage Options that Never Expire
When hosting on **Vercel** for free without project expiration:
| Provider | Free Tier Details | Inactivity / Expiration Policy | Best For |
|---|---|---|---|
| **Cloudinary** *(Recommended)* | **25 GB** free bandwidth & storage per month | **Never sleeps, never expires** | Beverage photo uploads via direct unsigned presets or API |
| **AWS S3** | 5 GB standard storage | 12 months only (expires after 1 year!), credit card required | Enterprise setups with dedicated cloud billing |
| **Supabase** | **500 MB** Postgres + **1 GB** Storage Bucket | Pauses after 7 days of 0 API requests (can unpause in 1 click or keep alive via a free GitHub Action cron ping) | All-in-one Postgres + Auth + Storage |
| **Cloudflare R2** | 10 GB storage with $0 egress fees | Permanent free tier (credit card required for verification) | High-volume asset delivery |
| **Embedded / Local Storage** *(Included in this app)* | Disk storage at `/uploads/beverages/` | Zero external API keys needed | Local & container deployments |

### 📸 Beverage Image Upload Feature
- **Admin Image Studio (`/admin`)**:
  - The first registered user (Admin) can upload custom can/bottle photos for any existing or new beverage flavor.
  - Supports:
    1. **Local Persistent Storage**: Uploads are saved to `./uploads/beverages/` and served via `/uploads/beverages/...`.
    2. **Cloudinary Direct Upload**: Connects to your free Cloudinary account with an unsigned preset, uploading directly to Cloudinary's global CDN.
    3. **Preset Photography Library**: Pick from curated high-resolution studio shots.
    4. **Direct URL Association**: Paste any public image URL.
  - Automatically associates the image with `products.image_url` in the database and immediately updates the `/shop` grid!

### 3. Vercel Hosting Guide
To deploy this project:
1. **Frontend (Vercel)**: Push to GitHub and import into Vercel. Framework preset: **Vite**. Build command: `npm run build`, output directory: `dist`.
2. **Backend**:
   - **Option A (Render / Railway Free Tier)**: Run `npm run start` with a persistent volume for the SQLite database.
   - **Option B (Serverless with Neon/Supabase + Vercel)**: Swap `server/db.ts` connection string to your Postgres URL and deploy API routes under `/api`.

---

## 🚀 Quickstart Commands

### 1. Install Dependencies
```bash
npm install
```

### 2. Environment Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Default `.env` variables:
```env
PORT=3000
CLIENT_ORIGIN="http://localhost:3000"
JWT_SECRET="aura_artisan_beverage_super_secret_jwt_key_2026"
```

### 3. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser. The SQLite database is automatically initialized and seeded with the 7 signature beverage flavors on first launch!

### 4. Build & Production Start
```bash
npm run build
npm run start
```

---

## 🧪 Test Checklist

1. **Sign Up & First User Admin Rule**:
   - Navigate to `/` and click "Create Account".
   - Enter your name, email, and password ($\ge 8$ characters).
   - The first user to register is automatically granted the **`admin`** role.
2. **Email Confirmation**:
   - The confirmation screen will display the 6-digit code (simulated preview for development).
   - Enter the code to verify your email and sign in.
3. **Cart Operations & Instant Telemetry**:
   - Go to `/shop` and click "Add to Cart" on *Cranberry Sparkle* and *Mango Rush*.
   - Open the Cart Drawer to adjust quantities (+ / -) or remove items.
   - Every cart modification is immediately recorded in the `cart_events` table with server timestamps.
4. **Offline Fault Tolerance**:
   - If the server or network connection drops, cart modifications still update the UI immediately and are queued in `pending_events_<userId>` for automatic background retry.
5. **Cart Persistence Across Refresh**:
   - Refresh the browser or reopen the tab. Your cart items, quantities, and pricing remain intact.
6. **Multi-User Isolation**:
   - Click Logout. The in-memory cart resets to 0.
   - Sign up or log in as a second user. Notice their cart is completely empty and independent!
   - Log back into the first account; the previous cart is fully restored from `cart-<userId>`.
7. **Mock Purchase Flow**:
   - In the cart drawer, click "Proceed to Purchase".
   - Select UPI, Mock Card, or COD, and click "Pay Now".
   - The server computes prices from the database, executes an atomic order transaction, fires celebration confetti, clears the cart, and appends the order to "My Orders".
8. **Admin Panel & SQL Diagnostics**:
   - Log in as the first user and click "Admin Panel" in the header.
   - Upload new beverage flavors, inspect the live cart events feed, and run diagnostic SQL queries.

---

## 📊 SQL Diagnostic Queries

You can run these directly in the in-app **Admin Panel > SQL Diagnostics** tab or using the SQLite CLI:

### 1. View Each User's Purchases & Total Spent
```sql
SELECT 
  u.id AS user_id,
  u.name AS customer_name,
  u.email,
  COUNT(o.id) AS total_orders_placed,
  COALESCE(SUM(o.total), 0) AS total_spent_inr
FROM users u
LEFT JOIN orders o ON o.user_id = u.id
GROUP BY u.id
ORDER BY total_spent_inr DESC;
```

### 2. View Cart Add/Remove History by Date & Timestamp
```sql
SELECT 
  ce.created_at AS event_timestamp,
  u.name AS customer_name,
  p.name AS beverage_flavor,
  ce.action AS action_taken,
  ce.qty AS resulting_quantity
FROM cart_events ce
JOIN users u ON u.id = ce.user_id
JOIN products p ON p.id = ce.product_id
ORDER BY ce.created_at DESC
LIMIT 50;
```

### 3. View Best-Selling Beverages
```sql
SELECT 
  oi.name_snapshot AS flavor,
  SUM(oi.qty) AS total_bottles_sold,
  SUM(oi.qty * oi.price_snapshot) AS gross_sales_inr
FROM order_items oi
GROUP BY oi.name_snapshot
ORDER BY total_bottles_sold DESC;
```

### 4. Inspect Cart Drop-Off / Funnel Metrics
```sql
SELECT 
  action, 
  COUNT(*) AS total_events
FROM cart_events
GROUP BY action;
```

---

## 📂 Project Structure

```
├── data/
│   └── beverage_store.db      # SQLite database file (created automatically)
├── server/
│   ├── db.ts                  # SQLite tables, seeds, & queries
│   ├── auth.ts                # bcrypt hashing, JWT httpOnly cookie middleware
│   └── routes.ts              # Zod-validated endpoints for auth, products, cart events, orders, admin
├── src/
│   ├── assets/images/         # High-resolution generated beverage studio photography
│   ├── components/
│   │   ├── Navbar.tsx         # 3-Zone Top Bar with Dark/Light toggle and cart trigger
│   │   ├── CartDrawer.tsx     # Slide-over cart drawer with qty +/- and summary
│   │   ├── PaymentModal.tsx   # Mock payment simulation with fault tolerance
│   │   ├── ConfirmationModal.tsx # Post-purchase receipt with order number & date
│   │   └── DatabaseArchitectureModal.tsx # Supabase / Cloudinary / Vercel guide
│   ├── context/
│   │   ├── AuthContext.tsx    # User session and authentication state
│   │   └── ThemeContext.tsx   # Dark/Light mode theme provider
│   ├── pages/
│   │   ├── AuthPage.tsx       # Sign In, Sign Up, inline validation, email verify
│   │   ├── ShopPage.tsx       # Hero, 7 beverage cards in ₹, and "My orders"
│   │   └── AdminPage.tsx      # Beverage editor, live cart stream, SQL console
│   ├── services/
│   │   └── api.ts             # Typed fetch client with credentials: include
│   ├── store/
│   │   └── useCartStore.ts    # Zustand cart with per-user persist & offline queue
│   ├── types/
│   │   └── index.ts           # Shared TypeScript interfaces
│   ├── App.tsx                # React Router setup
│   ├── main.tsx               # React entry point
│   └── index.css              # Tailwind CSS v4 styling & dark mode custom variant
├── server.ts                  # Express full-stack entry point with Vite middleware
├── .env.example
├── package.json
└── README.md
```
