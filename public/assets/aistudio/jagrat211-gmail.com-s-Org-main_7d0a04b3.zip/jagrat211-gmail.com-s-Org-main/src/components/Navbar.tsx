import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Sun, Moon, LogOut, ShieldCheck, Zap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useCartStore } from '../store/useCartStore';

interface NavbarProps {
  onScrollToOrders?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onScrollToOrders }) => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const itemsCount = useCartStore((state) => state.getTotalCount());
  const openCart = useCartStore((state) => state.openCart);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-amber-200/50 bg-gradient-to-r from-amber-50/75 via-orange-50/60 to-emerald-50/65 backdrop-blur-md transition-colors dark:border-slate-800/80 dark:bg-slate-900/90 dark:from-slate-900/90 dark:via-slate-900/90 dark:to-slate-950/90">
      <div className="mx-auto flex h-17 max-w-7xl items-center justify-between gap-6 px-4 sm:px-6 lg:px-8">
        
        {/* Zone 1: Logo Lockup with Circular Badge */}
        <Link
          to="/"
          className="group flex items-center gap-3 transition-transform hover:scale-[1.01] shrink-0"
        >
          {/* Aesthetic Gen-Z Circular Logo Badge */}
          <div className="relative flex h-11 w-11 shrink-0 flex-col items-center justify-center rounded-full border-2 border-amber-400 bg-white shadow-xs ring-2 ring-amber-300/30 transition-transform group-hover:rotate-6 dark:border-amber-400/80 dark:bg-slate-900">
            <span className="text-[8.5px] font-black uppercase tracking-tighter text-slate-900 dark:text-white leading-none text-center">
              AURRA
            </span>
            <span className="text-[7.5px] font-extrabold uppercase tracking-tight text-amber-500 leading-none">
              BLAST
            </span>
            <span className="mt-0.5 rounded-full bg-emerald-500 px-1.5 py-[1px] text-[6.5px] font-black tracking-widest text-white leading-none">
              BEV
            </span>
          </div>

          {/* Typography Lockup */}
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-base sm:text-lg font-black tracking-tight text-slate-900 dark:text-white">
                Aurra Blast
              </span>
              <span className="rounded bg-amber-500/20 px-1 py-0.2 text-[10px] font-extrabold text-amber-700 dark:bg-amber-400/20 dark:text-amber-300">
                BEVERAGES
              </span>
            </div>
            <span className="text-[10.5px] font-semibold text-slate-500 dark:text-slate-400 tracking-tight flex items-center gap-1">
              <Zap className="h-2.5 w-2.5 text-amber-500 fill-amber-400" />
              The Next Generation of Energy.
            </span>
          </div>
        </Link>

        {/* Zone 2: Navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-semibold text-slate-700 dark:text-slate-300">
          <Link
            to="/"
            className="hover:text-amber-600 transition-colors dark:hover:text-amber-400 whitespace-nowrap shrink-0"
          >
            The 8 Flavors
          </Link>

          <Link
            to="/about"
            className="hover:text-amber-600 transition-colors dark:hover:text-amber-400 whitespace-nowrap shrink-0"
          >
            Our Vision & Estate
          </Link>
          
          {user && onScrollToOrders && (
            <button
              onClick={onScrollToOrders}
              className="hover:text-amber-600 transition-colors dark:hover:text-amber-400 whitespace-nowrap shrink-0"
            >
              My Orders
            </button>
          )}

          {user?.role === 'admin' && (
            <Link
              to="/admin"
              className="flex items-center gap-1.5 text-amber-600 hover:text-amber-700 font-bold transition-colors dark:text-amber-400 dark:hover:text-amber-300 whitespace-nowrap shrink-0"
            >
              <ShieldCheck className="h-4 w-4" />
              Admin Studio
            </Link>
          )}
        </nav>

        {/* Zone 3: Actions (Theme toggle, Cart button, User badge & Logout) */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Dark / Light Mode Toggle */}
          <button
            onClick={toggleTheme}
            aria-label="Toggle dark/light theme"
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-amber-200/80 bg-white/80 text-slate-600 transition-colors hover:bg-white hover:text-slate-900 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700 dark:hover:text-white"
          >
            {theme === 'dark' ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4" />}
          </button>

          {/* Cart Drawer Trigger */}
          {user && (
            <button
              onClick={openCart}
              aria-label="Open cart drawer"
              className="relative flex h-9 items-center gap-2 rounded-xl border border-amber-200/80 bg-white px-3 text-xs font-bold text-slate-800 shadow-xs transition-colors hover:bg-amber-50/50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              <ShoppingBag className="h-4 w-4 text-amber-500" />
              <span className="hidden sm:inline">Cart</span>
              <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-amber-500 px-1 text-xs font-black text-white tabular-nums">
                {itemsCount}
              </span>
            </button>
          )}

          {/* User greeting & Logout or Sign In */}
          {user ? (
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex flex-col text-right">
                <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[120px]">
                  {user.name}
                </span>
                <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-400">
                  {user.role === 'admin' ? 'Store Admin' : 'Member'}
                </span>
              </div>
              <button
                onClick={handleLogout}
                title="Log out"
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white/80 text-slate-500 hover:border-red-200 hover:bg-red-50 hover:text-red-600 transition-colors dark:border-slate-800 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-red-950/30 dark:hover:text-red-400"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <Link
              to="/auth"
              className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-extrabold text-white shadow-sm hover:bg-amber-600 transition-all active:scale-95 whitespace-nowrap"
            >
              Sign In
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};
