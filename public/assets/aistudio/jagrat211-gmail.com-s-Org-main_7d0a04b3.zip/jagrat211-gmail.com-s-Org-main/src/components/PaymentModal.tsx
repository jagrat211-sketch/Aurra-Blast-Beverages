import React, { useState } from 'react';
import { X, ShieldCheck, CheckCircle2, AlertCircle, Loader2, Sparkles, CreditCard, Smartphone } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useCartStore } from '../store/useCartStore';
import { api } from '../services/api';
import { Order } from '../types';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (order: Order) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { items, getGrandTotal, clearCart, closeCart } = useCartStore();
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'cod'>('upi');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const grandTotal = getGrandTotal();

  const handlePayNow = async () => {
    setLoading(true);
    setError(null);

    try {
      // 1. Prepare items payload for server (server computes prices from DB)
      const payloadItems = items.map((i) => ({
        productId: i.productId,
        qty: i.qty,
      }));

      // 2. Call backend order creation endpoint
      const res = await api.createOrder(payloadItems);

      // 3. Trigger celebration confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore confetti errors
      }

      // 4. On successful purchase: clear cart, close drawer & modal, trigger confirmation
      clearCart();
      closeCart();
      onClose();
      onSuccess(res.order);
    } catch (err: any) {
      // Critical requirement: purchase must show clear error if server unreachable and must NOT empty cart
      console.error('Order creation failed:', err);
      setError(err.message || 'Payment simulation failed. Your cart was preserved.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={onClose} />

      <div className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl transition-all dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400">
              <Sparkles className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Aurra Express Checkout</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Instant Mock Payment Gateway</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="mt-4 flex items-start gap-2.5 rounded-xl bg-red-50 p-3.5 text-xs text-red-700 dark:bg-red-950/40 dark:text-red-400 border border-red-200 dark:border-red-900/50">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Transaction Error: </span>
              {error}
              <div className="mt-1 text-[11px] text-red-600 dark:text-red-400">
                Notice: Your cart has not been emptied. You may retry now or later.
              </div>
            </div>
          </div>
        )}

        {/* Order item preview */}
        <div className="mt-4 rounded-xl bg-slate-50 p-3.5 dark:bg-slate-800/60">
          <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            <span>Beverages in Order ({items.length})</span>
            <span className="tabular-nums">₹{grandTotal}</span>
          </div>
          <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1">
            {items.map((item) => (
              <div key={item.productId} className="flex justify-between text-xs text-slate-600 dark:text-slate-400">
                <span className="truncate pr-2">
                  {item.qty}x {item.name}
                </span>
                <span className="tabular-nums font-medium text-slate-900 dark:text-slate-200 shrink-0">
                  ₹{item.price * item.qty}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Payment simulator methods */}
        <div className="mt-5">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            Select Mock Payment Method
          </label>
          <div className="mt-2 grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMethod('upi')}
              className={`flex flex-col items-center justify-center gap-1.5 rounded-xl border p-3 text-center transition-all ${
                paymentMethod === 'upi'
                  ? 'border-amber-500 bg-amber-50/50 text-amber-700 dark:border-amber-400 dark:bg-amber-950/30 dark:text-amber-300 shadow-xs'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <Smartphone className="h-5 w-5" />
              <span className="text-xs font-medium">Instant UPI</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('card')}
              className={`flex flex-col items-center justify-center gap-1.5 rounded-xl border p-3 text-center transition-all ${
                paymentMethod === 'card'
                  ? 'border-amber-500 bg-amber-50/50 text-amber-700 dark:border-amber-400 dark:bg-amber-950/30 dark:text-amber-300 shadow-xs'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <CreditCard className="h-5 w-5" />
              <span className="text-xs font-medium">Mock Card</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('cod')}
              className={`flex flex-col items-center justify-center gap-1.5 rounded-xl border p-3 text-center transition-all ${
                paymentMethod === 'cod'
                  ? 'border-amber-500 bg-amber-50/50 text-amber-700 dark:border-amber-400 dark:bg-amber-950/30 dark:text-amber-300 shadow-xs'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <CheckCircle2 className="h-5 w-5" />
              <span className="text-xs font-medium">Pay on Delivery</span>
            </button>
          </div>
        </div>

        {/* Security badge notice */}
        <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50/70 p-3 text-xs text-emerald-800 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-300 flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
          <span>
            Safe sandbox: No real money or card numbers are collected or stored.
          </span>
        </div>

        {/* Action button */}
        <div className="mt-6 flex gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="flex-1 rounded-xl border border-slate-200 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handlePayNow}
            disabled={loading}
            className="flex-2 flex items-center justify-center gap-2 rounded-xl bg-amber-500 py-2.5 text-xs font-bold text-white shadow-md hover:bg-amber-600 transition-all active:scale-[0.99] disabled:opacity-60"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Authorizing & Recording...</span>
              </>
            ) : (
              <span>Pay Now · ₹{grandTotal}</span>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
