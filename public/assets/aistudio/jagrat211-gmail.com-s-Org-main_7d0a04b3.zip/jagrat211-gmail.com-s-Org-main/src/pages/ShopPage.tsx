import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ShoppingBag,
  Plus,
  Check,
  Package,
  Calendar,
  Sparkles,
  RefreshCw,
  Flame,
  Droplets,
  ArrowRight,
  ShieldCheck,
  Upload,
  UserCheck,
  Compass
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCartStore } from '../store/useCartStore';
import { api } from '../services/api';
import { Product, Order } from '../types';
import { CartDrawer } from '../components/CartDrawer';
import { PaymentModal } from '../components/PaymentModal';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { AuthModal } from '../components/AuthModal';
import { BeverageImageUploadModal } from '../components/BeverageImageUploadModal';

interface ShopPageProps {
  ordersRef: React.RefObject<HTMLDivElement | null>;
}

export const ShopPage: React.FC<ShopPageProps> = ({ ordersRef }) => {
  const { user } = useAuth();

  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [addedAnimationId, setAddedAnimationId] = useState<string | null>(null);

  // Modals state
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  
  // Auth Modal trigger for unauthenticated users clicking "Buy"
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [pendingProductToBuy, setPendingProductToBuy] = useState<Product | null>(null);

  // Admin image replacement state
  const [adminUploadProduct, setAdminUploadProduct] = useState<Product | null>(null);

  const addItem = useCartStore((state) => state.addItem);
  const openCart = useCartStore((state) => state.openCart);

  // Load products (publicly available for all visitors)
  const fetchProducts = async () => {
    setLoadingProducts(true);
    try {
      const res = await api.getProducts();
      setProducts(res.products || []);
    } catch (err) {
      console.error('Failed to load products:', err);
    } finally {
      setLoadingProducts(false);
    }
  };

  // Load user orders (if logged in)
  const fetchOrders = async () => {
    if (!user) return;
    setLoadingOrders(true);
    try {
      const res = await api.getOrders();
      setOrders(res.orders || []);
    } catch (err) {
      console.error('Failed to load orders:', err);
    } finally {
      setLoadingOrders(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    if (user) {
      fetchOrders();
    } else {
      setOrders([]);
    }
  }, [user]);

  // Handle Buy / Add to Cart: Requires login before proceeding
  const handleBuyClick = (product: Product) => {
    if (!user) {
      // User must log in to buy
      setPendingProductToBuy(product);
      setIsAuthModalOpen(true);
      return;
    }

    // Authenticated user adds to cart
    addItem(product, 1);
    setAddedAnimationId(product.id);
    setTimeout(() => {
      setAddedAnimationId(null);
    }, 1200);

    // Open cart drawer immediately so they can review & checkout
    openCart();
  };

  const handleAuthSuccess = (productToAdd?: Product | null) => {
    if (productToAdd) {
      addItem(productToAdd, 1);
      openCart();
      setPendingProductToBuy(null);
    }
    fetchOrders();
  };

  const handlePaymentSuccess = (order: Order) => {
    setConfirmedOrder(order);
    fetchOrders();
  };

  const scrollToOrders = () => {
    ordersRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen pb-20">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 py-16 sm:py-24 text-white">
        <div className="absolute inset-0 z-0 opacity-40">
          <img
            src="/src/assets/images/hero_beverage_can_1793439801479.jpg"
            alt="Aurra Artisanal sparkling beverages"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent" />
        </div>

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-xl bg-amber-500/25 px-3.5 py-1.5 text-xs font-extrabold text-amber-300 backdrop-blur-md mb-4 border border-amber-400/30">
              <Sparkles className="h-4 w-4 text-amber-400" />
              <span>AURRA BLAST BEVERAGES · THE NEXT GENERATION OF ENERGY.</span>
            </div>
            
            <h1 className="text-3xl font-black tracking-tight sm:text-5xl text-balance">
              The Next Generation of Energy.
            </h1>
            
            <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed max-w-xl">
              {user ? (
                <>Welcome back, <span className="font-bold text-white">{user.name}</span>. Fuel your lifestyle with our 8 clean botanical energy sparklers. Zero taurine jitters, zero sugar crash.</>
              ) : (
                <>Next-gen clean sparkling energy powered by cold-pressed fruits, natural green tea botanicals, and sparkling mountain spring water. Select any of our 8 flavors below to buy.</>
              )}
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4 text-xs text-slate-300">
              <div className="flex items-center gap-1.5">
                <Droplets className="h-4 w-4 text-amber-400" />
                <span>100% Real Fruit Extract</span>
              </div>
              <span className="text-slate-600">·</span>
              <div className="flex items-center gap-1.5">
                <Flame className="h-4 w-4 text-orange-400" />
                <span>&lt; 50 kcal / bottle</span>
              </div>
              <span className="text-slate-600">·</span>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                <span>Free Delivery above ₹499</span>
              </div>
              <span className="text-slate-600">·</span>
              <Link
                to="/about"
                className="flex items-center gap-1 font-semibold text-amber-400 hover:text-amber-300 transition-colors"
              >
                <Compass className="h-3.5 w-3.5" />
                <span>Our Vision & Estate →</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-12">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4 border-b border-slate-200/80 pb-4 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                The 8 Signature Flavors
              </h2>
              {user?.role === 'admin' && (
                <span className="rounded-md bg-amber-100 px-2 py-0.5 text-[11px] font-bold text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                  Admin Mode: You can replace any beverage photo
                </span>
              )}
            </div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Click "Buy Now" to add to cart and checkout with simulated payment
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              {products.length} Flavors In Stock
            </span>
          </div>
        </div>

        {/* Product Grid: Shows the 8 Flavor Drinks */}
        {loadingProducts ? (
          <div className="flex h-64 items-center justify-center">
            <RefreshCw className="h-7 w-7 animate-spin text-amber-500" />
          </div>
        ) : products.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 p-12 text-center dark:border-slate-800">
            <p className="text-sm text-slate-500">No active beverage flavors found in database.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => {
              const isAdded = addedAnimationId === product.id;

              return (
                <div
                  key={product.id}
                  className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/80 bg-white transition-all duration-200 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800/80 dark:bg-slate-900"
                >
                  {/* Beverage Image Frame */}
                  <div className="relative aspect-4/3 w-full overflow-hidden bg-slate-100 dark:bg-slate-800">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-105"
                      onError={(e) => {
                        const el = e.target as HTMLElement;
                        el.style.display = 'none';
                        const parent = el.parentElement;
                        if (parent) {
                          parent.classList.add('flex', 'items-center', 'justify-center', 'bg-amber-50', 'dark:bg-slate-800');
                          parent.innerHTML = `<span class="text-xs font-bold text-amber-700 dark:text-amber-300">${product.name}</span>`;
                        }
                      }}
                    />
                    
                    {/* Volume & calorie micro-tag */}
                    <div className="absolute bottom-2.5 left-2.5 rounded-md bg-slate-900/75 px-2 py-0.5 text-[11px] font-medium text-white backdrop-blur-xs">
                      {product.volume} · {product.calories} kcal
                    </div>

                    {/* Admin Image Replace Action directly on Card */}
                    {user?.role === 'admin' && (
                      <button
                        type="button"
                        onClick={() => setAdminUploadProduct(product)}
                        title="Admin: Replace this beverage's image"
                        className="absolute top-2.5 right-2.5 flex items-center gap-1 rounded-lg bg-amber-500/90 hover:bg-amber-600 px-2.5 py-1 text-[11px] font-bold text-white shadow-xs backdrop-blur-xs transition-colors"
                      >
                        <Upload className="h-3 w-3" />
                        <span>Replace Image</span>
                      </button>
                    )}
                  </div>

                  {/* Card Content */}
                  <div className="flex flex-1 flex-col p-4 sm:p-5">
                    <div className="flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <h3 className="text-base font-bold text-slate-900 dark:text-white">
                          {product.name}
                        </h3>
                        <span className="text-base font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                          ₹{product.price}
                        </span>
                      </div>

                      <p className="mt-1 text-xs font-medium text-slate-500 dark:text-slate-400">
                        {product.flavor}
                      </p>

                      <p className="mt-2 text-xs text-slate-600 line-clamp-2 leading-relaxed dark:text-slate-300">
                        {product.description}
                      </p>
                    </div>

                    {/* Buy Now / Add to Cart button */}
                    <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                      <button
                        onClick={() => handleBuyClick(product)}
                        className={`w-full flex items-center justify-center gap-2 rounded-xl py-2.5 px-4 text-xs font-bold transition-all duration-150 active:scale-95 ${
                          isAdded
                            ? 'bg-emerald-600 text-white'
                            : 'bg-amber-500 text-white hover:bg-amber-600 shadow-xs'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="h-4 w-4" />
                            <span>Added to Cart!</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="h-4 w-4" />
                            <span>Buy · ₹{product.price}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Section 2: "My orders" past orders (when logged in) */}
        {user && (
          <section ref={ordersRef} className="mt-20 pt-10 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
                  <Package className="h-5 w-5 text-amber-500" />
                  My Orders
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  Track your previous beverage purchases and billing snapshots
                </p>
              </div>
              <button
                onClick={fetchOrders}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${loadingOrders ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {loadingOrders ? (
              <div className="py-12 text-center text-xs text-slate-400">Loading order history...</div>
            ) : orders.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-slate-900">
                <Package className="mx-auto h-8 w-8 text-slate-300 dark:text-slate-600 mb-2" />
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">No past orders yet</p>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  Select your favorite flavors from the 8 options above to complete your first order.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((ord) => {
                  const dateString = new Date(ord.created_at).toLocaleString('en-IN', {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  });

                  return (
                    <div
                      key={ord.id}
                      className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs transition-colors dark:border-slate-800 dark:bg-slate-900"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3 dark:border-slate-800">
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                            #{ord.id}
                          </span>
                          <span className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                            <Calendar className="h-3.5 w-3.5" />
                            {dateString}
                          </span>
                          <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400">
                            {ord.status.toUpperCase()}
                          </span>
                        </div>
                        <div className="text-sm font-bold text-slate-900 dark:text-white tabular-nums">
                          Total: ₹{ord.total}
                        </div>
                      </div>

                      {/* Order items snapshot */}
                      <div className="mt-3.5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
                        {ord.items?.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-xs dark:bg-slate-800/50"
                          >
                            <span className="font-medium text-slate-700 dark:text-slate-300 truncate pr-2">
                              {item.qty}x {item.name_snapshot}
                            </span>
                            <span className="font-semibold text-slate-900 dark:text-white tabular-nums shrink-0">
                              ₹{item.price_snapshot * item.qty}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        )}

      </main>

      {/* Cart Drawer */}
      <CartDrawer
        onProceedToCheckout={() => setIsPaymentModalOpen(true)}
      />

      {/* Payment Modal */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onSuccess={handlePaymentSuccess}
      />

      {/* Confirmation Modal */}
      <ConfirmationModal
        order={confirmedOrder}
        onClose={() => setConfirmedOrder(null)}
        onViewOrders={scrollToOrders}
      />

      {/* Auth Modal (Prompted when visitor clicks Buy without logging in) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        pendingProductToBuy={pendingProductToBuy}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Admin Image Replacement Studio Modal */}
      <BeverageImageUploadModal
        isOpen={Boolean(adminUploadProduct)}
        product={adminUploadProduct}
        onClose={() => setAdminUploadProduct(null)}
        onSuccess={(updatedProduct) => {
          setProducts((prev) =>
            prev.map((item) => (item.id === updatedProduct.id ? updatedProduct : item))
          );
          setAdminUploadProduct(null);
        }}
      />

    </div>
  );
};
