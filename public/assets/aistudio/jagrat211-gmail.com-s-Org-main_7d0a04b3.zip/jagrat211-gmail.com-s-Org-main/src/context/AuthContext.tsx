import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { User } from '../types';
import { api } from '../services/api';
import { useCartStore } from '../store/useCartStore';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; user?: User; requiresVerification?: boolean; email?: string; devVerificationCode?: string }>;
  signup: (name: string, email: string, password: string) => Promise<{ success?: boolean; requiresVerification: boolean; email: string; message: string; devVerificationCode?: string }>;
  verifyEmail: (email: string, code: string) => Promise<{ success: boolean; user: User }>;
  resendCode: (email: string) => Promise<{ success: boolean; devVerificationCode?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const setCartUser = useCartStore((state) => state.setUser);

  const fetchCurrentUser = useCallback(async () => {
    try {
      const res = await api.getMe();
      setUser(res.user);
      setCartUser(res.user);
    } catch {
      setUser(null);
      setCartUser(null);
    } finally {
      setLoading(false);
    }
  }, [setCartUser]);

  useEffect(() => {
    fetchCurrentUser();
  }, [fetchCurrentUser]);

  const login = async (email: string, password: string) => {
    const res = await api.login({ email, password });
    if (res.user) {
      setUser(res.user);
      setCartUser(res.user);
    }
    return res;
  };

  const signup = async (name: string, email: string, password: string) => {
    return await api.signup({ name, email, password });
  };

  const verifyEmail = async (email: string, code: string) => {
    const res = await api.verifyEmail({ email, code });
    if (res.user) {
      setUser(res.user);
      setCartUser(res.user);
    }
    return res;
  };

  const resendCode = async (email: string) => {
    return await api.resendCode(email);
  };

  const logout = async () => {
    try {
      await api.logout();
    } catch (err) {
      console.warn('Logout error:', err);
    } finally {
      setUser(null);
      setCartUser(null);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        signup,
        verifyEmail,
        resendCode,
        logout,
        refreshUser: fetchCurrentUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
