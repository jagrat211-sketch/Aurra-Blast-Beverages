import React, { useRef } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { Navbar } from './components/Navbar';
import { ShopPage } from './pages/ShopPage';
import { AboutStoryPage } from './pages/AboutStoryPage';
import { AdminPage } from './pages/AdminPage';
import { AuthPage } from './pages/AuthPage';

export default function App() {
  const ordersRef = useRef<HTMLDivElement | null>(null);

  const handleScrollToOrders = () => {
    if (ordersRef.current) {
      ordersRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <div className="min-h-screen flex flex-col bg-[#f7f8fa] text-slate-800 transition-colors duration-200 dark:bg-slate-950 dark:text-slate-100">
            {/* Light Aesthetic Gen-Z Shaded Top Bar */}
            <Navbar onScrollToOrders={handleScrollToOrders} />

            {/* 2-Page Website Routes */}
            <div className="flex-1">
              <Routes>
                {/* Page 1: The 8 Flavors Storefront, Buy Option & Shopping Cart */}
                <Route path="/" element={<ShopPage ordersRef={ordersRef} />} />

                {/* Page 2: Our Vision, Estate Address & Verified Testimonials */}
                <Route path="/about" element={<AboutStoryPage />} />

                {/* Optional /auth direct route and Admin panel */}
                <Route path="/auth" element={<AuthPage />} />
                <Route path="/admin" element={<AdminPage />} />
                
                {/* Fallback & aliases */}
                <Route path="/shop" element={<Navigate to="/" replace />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </div>

            {/* Aesthetic Gen-Z Footer */}
            <footer className="border-t border-amber-200/40 bg-white/90 py-7 dark:border-slate-800 dark:bg-slate-900 text-xs text-slate-500 dark:text-slate-400">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-slate-900 dark:text-white">Aurra Blast Beverages</span>
                  <span>·</span>
                  <span className="text-amber-600 dark:text-amber-400 font-semibold">The Next Generation of Energy.</span>
                </div>

                <div className="flex items-center gap-4 text-[11px]">
                  <span>8 Signature Clean Energy Flavors</span>
                  <span>·</span>
                  <span>₹ INR Pricing</span>
                  <span>·</span>
                  <span>Crafted in India</span>
                </div>
              </div>
            </footer>
          </div>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
